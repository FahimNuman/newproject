﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcProject.Models
{
    public class Equipment
    {
        public int EquipmentID { get; set; }
        public string Name { get; set; }
        public int Count { get; set; }
        public DateTime EntryDate { get; set; }

        public static List<Equipment> LstEquipment()
        {
            List<Equipment> list = new List<Equipment>();

            for(int i =1; i<30;i++)
            {
                Equipment equipment = new Equipment();
                equipment.Name = "Laptop"+i.ToString();
                equipment.Count = i*5;
                equipment.EntryDate = DateTime.Now;
                list.Add(equipment);

            }

            return list;
        }

    }
   
}